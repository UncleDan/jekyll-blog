<?php
require('install.php');
?>
