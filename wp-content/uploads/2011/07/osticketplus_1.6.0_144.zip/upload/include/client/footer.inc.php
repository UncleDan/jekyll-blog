 <div style="clear:both"></div> 
 </div>
 <div id="footer"><?=_('Copyright &copy; osTicket.com. All rights reserved')?></div>
 <div align="center">
     <a id="powered_by" href="http://osticket.com"><img src="./images/poweredby.jpg" width="126" height="23" alt="<?=_('Powered by osTicket')?>"></a></div>
</div>
</body>
</html>
