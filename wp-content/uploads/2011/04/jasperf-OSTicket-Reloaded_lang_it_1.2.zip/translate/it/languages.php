<?php

#Disable direct access.
if (!strcasecmp(basename($_SERVER['SCRIPT_NAME']), basename( __FILE__ ))) die ('kwaheri rafiki!');

// Here is the original name on each idiom.
// use the link: http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
$LANG['AR_NAME'] = 'العربية';
$LANG['CS_NAME'] = 'česky';
$LANG['ES_NAME'] = 'Español';
$LANG['FR_NAME'] = 'Français';
$LANG['IT_NAME'] = 'Italiano';
$LANG['PT_NAME'] = 'Português';
$LANG['PT_BR_NAME'] = 'Português Brasil';
$LANG['NL_NAME'] = 'Nederlands';
$LANG['RU_NAME'] = 'русский язык';
$LANG['US_NAME'] = 'English';
 
?>