Thank you for trying osTicket V1.6 ST (Feb 09,2010).

Version
 osTicket v1.6 ST (stable)

Directories
 upload  =>Files to upload to the webserver...e.g support, helpdesk or osticket i.e http://yourdomain.com/support
 scripts =>Helper scripts for remote piping ( More to come)

For upto date documentation please refer to osTicket wiki. http://www.osticket.com/wiki

For all other questions and support please visit our forums. http://osticket.com/forums/

We provide installation services and commercial support. Contact us today!
http://osticket.com/support/

Peter Rotich

