Theme Name: Quadruple Blue MOD
Theme URI: http://www.uncledan.it/web/quadruple-blue-mod/
Author: UncleDan
Author URI: http://www.uncledan.it/
Description: Quadruple Blue MOD is based on the Wordpress theme created by Small Potato for WordPress 2.0 series. Modded by UncleDan.
Version: 1.0.001
Original Theme URI: http://www.wpdesigner.com/2007/01/26/quadruple-blue/
Original Author: Small Potato
Original Author URI: http://www.wpdesigner.com/

	Released under GPL.

===========
INSTALLATION
===========

- Unzip the downloaded file. You'll get a folder named "quadruple-blue-mod"
- Upload the entire "quadruple-blue-mod" folder to your "wp-content/themes/" folder
- Place your own logo image in the folder "wp-content/themes/quadruple-blue-mod/images/"
  saving it as "logo728x90.png" (or "logo468x60.png") and replacing the existing one
- Login into WordPress administration
- Click on the 'Presentation" tab
- Click on the "quadruple-blue-mod" theme thumbnail/screenshot or title

That's it. Go back to the front page of your blog and hit refresh to see your newly installed theme.

=============
CUSTOMIZATION
=============

- Use alignleft or alignright to make your images float left or right. For example: <img src="yourimage.gif" class="alignleft">

=============
TIP
=============

- Use alignleft or alignright to make your images float left or right. For example: <img src="yourimage.gif" class="alignleft">

=============
CHANGELOG
=============

2009-03-27 Quadruple Blue MOD by UncleDan was born from the ashes of Quadruple Blue by Small Potato.
2009-03-28 QBM was modified to let localization via .mo/.po files.