<?php include (TEMPLATEPATH . '/right_sidebar.php'); ?>

		</div></div><!-- wide column wrap -->

	</div><!-- end page -->

	<div id="footer">
<p><strong><?php bloginfo('name'); ?></strong> <?php _e('is proudly powered by <a href="http://www.wordpress.org/" title="WordPress">WordPress</a>','qbm'); _e(' and <a href="http://www.wpdesigner.com" title="WordPress Themes">WPDesigner</a>.','qbm'); ?></p>
	</div>

</div>

<?php wp_footer(); ?>
</body>
</html>