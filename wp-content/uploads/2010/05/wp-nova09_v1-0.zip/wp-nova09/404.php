<?php get_header(); ?>
<?php get_sidebar(); ?>
<?php include (TEMPLATEPATH . '/right-sidebar.php'); ?>

<div id="content">
	<div class="page">
		<h2 class="center"><?php _e('Error 404 - Not Found','andreas09') ?></h2>
	</div>
</div>

<?php get_footer(); ?>
