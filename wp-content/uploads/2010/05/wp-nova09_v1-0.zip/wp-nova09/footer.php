</div>
<div class="clearingdiv">&nbsp;</div>
</div>

<div id="footer">

<a href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a> <?php _e('is powered by','andreas09'); ?> <a href="http://wordpress.org/">WordPress</a><br>
<br>
<?php _e('Design by','andreas09'); ?> <a href="http://andreasviklund.com">Andreas Viklund</a>
 | <?php _e('Ported by','andreas09'); ?> <a href="http://webgazette.co.uk">Ainslie</a>
<?php _e('<!-- | xyz translation by <a href="your url">your name</a> -->','andreas09'); ?><br>
<br>
Design Mod by <a href="http://www.uncledan.it">Uncledan.it</a>
</div>

<?php wp_footer(); ?>

</body>

</html>