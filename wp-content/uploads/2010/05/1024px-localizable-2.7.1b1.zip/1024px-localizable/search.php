<?php /* LOCALIZED */ ?>
<?php get_header(); ?>

<div id="content">
<?php if (have_posts()) : ?>
<h2><?php _e('Search results','1024px'); ?></h2>
<p class="timestamp"><?php _e('Your search for','1024px'); ?> "<?php echo wp_specialchars($s, 1); ?>" <?php _e('returned the following matches','1024px'); ?>:</p>
<?php while (have_posts()) : the_post(); ?>
<div class="post">
<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
<p class="timestamp"><?php the_time('j F, Y (H:i)') ?> | <?php the_category(', ') ?> | <?php comments_popup_link( __('No comments','1024px'), __('1 comment','1024px'), __('% comments','1024px'), '', ''); ?><?php edit_post_link('[e]',' | ',''); ?></p>
<div class="contenttext">
<?php the_excerpt() ?>
</div>
</div>

<?php endwhile; ?>

<div id="postnav">
<p><?php next_posts_link(__('&laquo; Older entries','1024px')) ?></p>
<p class="right"><?php previous_posts_link(__('Newer entries &raquo;','1024px')) ?></p>
</div>

<?php else : ?>
<h2><?php _e('No matches found!','1024px'); ?></h2>
<p><?php _e('Your search for','1024px'); ?> "<?php echo wp_specialchars($s, 1); ?>" <?php _e('gave no matches. Please try a different word, or use the navigation menus to search the site.','1024px'); ?></p>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>