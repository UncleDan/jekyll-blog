<?php /* LOCALIZED */ ?>
<h2><?php _e('Search','1024px'); ?></h2>
<form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div class="searchbox">
<label for="s"><?php _e('Find','1024px'); ?>:</label>
<input type="text" value="<?php echo wp_specialchars($s, 1); ?>" name="s" id="s" size="14" />
<input type="hidden" id="searchsubmit" value="Search" />
</div>
</form>