=== CSS Share Buttons ===
Contributors: purab
Donate link: http://wpapi.com/
Tags: Twitter, google Plus, Facebook, Linkedin, button, share button, share buttons
Requires at least: 3.0
Tested up to: 4.5
Stable tag: 1.0

Facebook, Twitter, Google Plus and LinkedIn Share buttons. Super Fast Loading, No Javascript, Only CSS. Responsive Design, Floting Sidebar Option

== Description ==

Facebook, Twitter, Google Plus and LinkedIn Share buttons.

The CSS Share Buttons easily allows your blog to be shared. Speedup you site with this share plugin.

= Super Fast =
This plugin is very light weight. As comapred to other Share button plugin This plugin is super fast.

We compared with all famous share button plugin. Our Plugin load CSS from CDN.

It show very lite share button only with HTML and CSS.
It does not load any javascript like other
We load only one CSS file with this plugin - only 1.5kb css file

[Step by step installation instructions >>](http://wpapi.com/fastest-minimal-css-social-share-button-wordpress-plugin/)

FEATURE::

1. Share with Facebook.

2. Share with Twitter.

3. Share with LinkedIn.

4. Share with Google Plus.

5. Floating Sidebar

6. Responsive Design


= Following is Demo URL for CSS Share Button: =
http://wpapi.com/improve-blog-websites-readability/


Tested upto 4.0

[Click here for customer support >>](http://wpapi.com/contact/)


#### Functionality

* New - CSS Share Buttons. Integrates the ability to share your post with one click.


== Installation ==

Follow the steps below to install the plugin.

1. Upload the CSS Share Buttons directory to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in wp
3. Go to "CSS Share Buttons" option to configure the button
4. [Step by step installation instructions >>](http://wpapi.com/fastest-minimal-css-social-share-button-wordpress-plugin/)


== Screenshots ==

1. Preview of CSS Share Buttons button with count on your blog


== Help ==

For help and support please contact us at contact [at] wpapi.com

= Following is Demo URL for CSS Share Button: =
[Click here for customer support >>](http://wpapi.com/contact/)

== Frequently Asked Questions == 
= Following is Demo URL for CSS Share Button: =
http://auk5.com/improve-blog-websites-readability/
coming soon

== Changelog == 

coming soon

== Upgrade Notice == 
coming soon
