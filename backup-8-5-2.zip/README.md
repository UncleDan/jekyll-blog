# Daniele Lolli (UncleDan)

This is the [**Jekyll**](https://jekyllrb.com/) version of my blog.

It is hosted on [**GitHub Pages**](https://pages.github.com/) and powered by the wonderful theme [**HydeJack**](https://hydejack.com/).

The DNS for custom domain is provided by [**Tophost.it**](https://www.tophost.it/).

The [**WordPress**](https://wordpress.org/) version is visible at this address:
[https://www.danielelolli.it/](https://www.danielelolli.it/)

*(I am currently changing provider for the WordPress version: if you experience some problems, be patient and come back in a few days... Thanks!)*
