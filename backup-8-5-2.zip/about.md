---
title: About
date: 2020-06-06T18:13:00+00:00
author: Daniele Lolli (UncleDan)
layout: page
menu: true
order: 1
---

# Daniele Lolli (UncleDan)

This is the [**Jekyll**](https://jekyllrb.com/) version of my blog.

It is hosted on [**Netlify**](https://www.netlify.com/) and powered by the wonderful theme [**HydeJack**](https://hydejack.com/).

The DNS for custom domain is provided by [**Aruba.it**](https://www.aruba.it/).