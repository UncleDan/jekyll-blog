Theme Name: Quadruple Blue MOD
Theme URI: http://www.uncledan.it/web/quadruple-blue-mod/
Original Theme URI: http://www.wpdesigner.com/2007/01/26/quadruple-blue/
Description: Quadruple Blue MOD is based on the Wordpress theme created by Small Potato for WordPress 2.0 series. Modded by UncleDan.
Version: 1.0.alpha1
Author: Small Potato
Author URI: http://www.wpdesigner.com/
Modder: UncleDan
Modder URI: http://www.uncledan.it/

	Released under GPL.

===========
INSTALLATION
===========

- Unzip the downloaded file. You'll get a folder named "quadruple-blue"
- Upload the entire "quadruple-blue" folder to your 'wp-content/themes/" folder
- Login into WordPress administration
- Click on the 'Presentation" tab
- Click on the "quadruple-blue-mg" theme thumbnail/screenshot or title

That's it. Go back to the front page of your blog and hit refresh to see your newly installed theme.

=============
CUSTOMIZATION
=============

- Use alignleft or alignright to make your images float left or right. For example: <img src="yourimage.gif" class="alignleft">

=============
TIP
=============

- Use alignleft or alignright to make your images float left or right. For example: <img src="yourimage.gif" class="alignleft">

=============
CHANGELOG
=============

2009-03-27 Quadruple Blue MOD by UncleDan was born from the ashes of Quadruple Blue by Small Potato.
2009-03-28 QBM was modified to let localization via .mo/.po files.