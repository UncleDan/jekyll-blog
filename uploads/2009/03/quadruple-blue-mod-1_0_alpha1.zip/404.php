<?php get_header(); ?>

			<div class="narrow_column">

<div class="post">

	<h2><?php _e('Not Found','qbm'); ?></h2>
	<div class="entry">
<p class="notfound"><?php _e('Sorry, but you are looking for something that isn&#39;t here.','qbm'); ?></p>
	</div>

</div>

			</div><!-- end narrow column -->

<?php get_footer(); ?>