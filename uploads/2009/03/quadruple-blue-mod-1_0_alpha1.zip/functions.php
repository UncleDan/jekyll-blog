<?php
load_theme_textdomain('qbm');
if ( function_exists('register_sidebar') )
    register_sidebars(3);
?>