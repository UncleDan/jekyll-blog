<?php /* LOCALIZED */ ?>
<div id="sidebar">

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(__('Sidebar','1024px')) ) : else : ?>

<h2><?php _e('Pages','1024px'); ?></h2>
<ul>
<?php /* <li><a href="<?php bloginfo('home'); ?>"><?php _e('Home','1024px'); ?></a></li> */ ?>
<?php wp_list_pages('sort_column=menu_order&title_li=') ?>
</ul>

<h2><?php _e('News','1024px'); ?></h2>
<ul>
<?php query_posts(""); ?>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endwhile ?>
</ul>

<?php get_search_form(); ?>

<h2><?php _e('Archive','1024px'); ?></h2>
<ul>
<?php wp_get_archives('type=monthly&show_post_count=1'); ?>
</ul>

<h2><?php _e('Meta', '1024px'); ?></h2>
<ul>
<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Strict', '1024px'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>', '1024px'); ?></a></li>
<li><a href="http://jigsaw.w3.org/css-validator/check/referer" title="<?php _e('This style validates as CSS 2.1', '1024px'); ?>"><?php _e('Valid <abbr title="Cascading Style Sheet">CSS</abbr>', '1024px'); ?></a></li>
<li><a href="http://gmpg.org/xfn/"><abbr title="<?php _e('XHTML Friends Network', '1024px'); ?>"><?php _e('XFN', '1024px'); ?></abbr></a></li>
<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.', '1024px'); ?>">WordPress</a></li>
</ul>

<h2><?php _e('Login or Admin', '1024px'); ?></h2>
<ul>
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
</ul>
<?php /*------------------------------------ I'll keep it clean, unquote if you need more blocks! -----------------------------------

<h2><?php _e('Categories','1024px'); ?></h2>
<ul>
<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=1&children=1&hide_empty=1'); ?>
</ul>

<?php if ( function_exists('wp_tag_cloud') ) : ?>
<h2><?php _e('Popular tags','1024px'); ?></h2>
<p>
<?php wp_tag_cloud('unit=em&smallest=0.8&largest=2'); ?>
</p>
<?php endif; ?>

<?php get_calendar(1); ?>

--------------------------------------------------------------------------------------------------------------------------------*/ ?>
<?php endif; ?>
<?php wp_meta(); ?>
</div>