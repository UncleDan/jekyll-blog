<?php /* LOCALIZED */ ?>
<?php get_header(); ?>

<div id="content">

<h2><?php _e('Error 404 - Page not found!','1024px'); ?></h2>
<p><?php _e('The page or entry that you tried to access could not be found. It may have been moved or deleted. Use the navigation menus or the search box to find what you are looking for!','1024px'); ?></p>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>