<?php /* LOCALIZED */ ?>
<?php get_header(); ?>

<div id="content">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<h2><?php the_title(); ?></h2>
<p class="timestamp"><?php the_time(__('j F, Y (H:i)','1024px')) ?> | <?php the_category(', ') ?> | <?php _e('By','1024px'); ?>: <?php the_author(); ?><?php edit_post_link('[e]',' | ',''); ?></p>
<div class="contenttext">
<?php the_content('<p>'.__('Read more &raquo;','1024px').'</p>'); ?>
</div>

<?php link_pages('<p><strong>'.__('Pages','1024px').':<strong> ', '</p>', 'number'); ?>
<?php the_tags('<p class="postmeta">'.__('Tags','1024px').': ', ', ', '</p>'); ?>

<div id="postnav">
<?php previous_post_link('<p>&laquo; %link</p>') ?><?php next_post_link('<p class="right">%link &raquo;</p>') ?>
</div>

<?php comments_template(); ?>

<?php endwhile; else: ?>
<p><?php _e('Entry could not be found!','1024px'); ?></p>
<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>