<?php /* LOCALIZED */ ?>
<div id="footer">
<p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> | <a href="<?php bloginfo('rss2_url'); ?>"><?php _e('Entries (RSS)','1024px'); ?></a> | <a href="<?php bloginfo('comments_rss2_url'); ?>"><?php _e('Comments (RSS)','1024px'); ?></a> | <a href="<?php bloginfo('url'); ?>/wp-admin/"><?php _e('Site administration','1024px'); ?></a> | <?php wp_loginout(); ?><br />
<span><?php _e('Powered by <a href="http://wordpress.org/">WordPress</a>','1024px'); ?> | <?php _e('<a href="http://andreasviklund.com/wordpress-themes/">Theme design</a> by <a href="http://andreasviklund.com/" title="Original theme design by Andreas Viklund">Andreas Viklund</a>','1024px'); ?></span></p>
</div>
<?php do_action('wp_footer'); ?>
</div>
</body>
</html>