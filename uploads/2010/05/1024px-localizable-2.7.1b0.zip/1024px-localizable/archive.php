<?php /* LOCALIZED */ ?>
<?php get_header(); ?>

<div id="content">
<?php if (have_posts()) : ?>
<?php $post = $posts[0]; ?>

<?php if (is_category()) { ?><h2><?php _e('Archive for category','1024px'); ?>: <?php echo single_cat_title(); ?></h2>
<div class="introtext"><?php echo category_description(); ?></div>
<?php } elseif (is_day()) { ?><h2><?php _e('Archive for date','1024px'); ?>: <?php the_time('F jS, Y'); ?></h2>
<?php } elseif (is_month()) { ?><h2><?php _e('Archive for month','1024px'); ?>: <?php the_time('F, Y'); ?></h2>
<?php } elseif (is_year()) { ?><h2><?php _e('Archive for year','1024px'); ?>: <?php the_time('Y'); ?></h2>
<?php } elseif (is_tag()) { ?><h2><?php single_tag_title('Archive for tag: '); ?></h2>
<?php } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?><h2><?php _e('Archive','1024px'); ?></h2>
<?php } ?>

<?php while (have_posts()) : the_post(); ?>
<div class="post">
<h3><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
<p class="timestamp"><?php the_time('j F, Y (H:i)') ?> | <?php the_category(', ') ?> | <?php _e('By','1024px'); ?>: <?php the_author(); ?><?php edit_post_link('[e]',' | ',''); ?></p>

<div class="contenttext">
<?php the_excerpt(); ?>
</div>

<p class="postmeta"><?php the_tags(__('Tags','1024px').': ', ', ', ' | '); ?>
<?php comments_popup_link( __('No comments','1024px'), __('1 comment','1024px'), __('% comments','1024px'), '', ''); ?></p>
</div>

<?php endwhile; ?>

<div id="postnav">
<p><?php next_posts_link(__('&laquo; Older entries','1024px')) ?></p>
<p class="right"><?php previous_posts_link(__('Newer entries &raquo;','1024px')) ?></p>
</div>

<?php else : ?>
<h2><?php _e('Error 404 - Page not found!','1024px'); ?></h2>
<p><?php _e('The page or entry that you tried to access could not be found. It may have been moved or deleted. Use the navigation menus or the search box to find what you are looking for!','1024px'); ?></p>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>