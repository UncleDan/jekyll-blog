<?php /* LOCALIZED */ ?>
<?php if ( !empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) : ?>
<p><?php _e('This page is password-protected. Enter your password to continue!','1024px'); ?></p>
<?php return; endif; ?>

<?php if ( $comments ) : ?>
<h2 id="comments"><?php _e('Comments','1024px'); ?></h2>

<?php foreach ($comments as $comment) : ?>

<div class="comment">
<div class="gravatarside"><?php if (function_exists('get_avatar')) { echo get_avatar($comment,$size='48'); } ?></div>
<p class="commenticon">
<strong><?php comment_type('Comment','Trackback','Pingback'); ?></strong> <?php _e('from','1024px'); ?> <strong><?php if ('' != get_comment_author_url()) { ?><a href="<?php comment_author_url(); ?>"><?php comment_author() ?></a><?php } else { comment_author(); } ?></strong>
<?php edit_comment_link('[e]',' | '); ?><br />
<strong><?php _e('Time','1024px'); ?></strong> <?php comment_date() ?> <?php _e('at','1024px'); ?> <?php comment_time(); ?></p>
<?php comment_text() ?>

<?php if ($comment->comment_approved == '0') : ?>
<p><strong><?php _e('Thank you for your comment! It has been added to the moderation queue and will be published here if approved by the webmaster.','1024px'); ?></strong></p>
<?php endif; ?>
</div>

<?php endforeach; ?>
<?php endif; ?>

<?php if ($post->comment_status == "open") : ?>
<div id="respond">
<h2><?php _e('Write a comment','1024px'); ?></h2>
<?php if (get_option('comment_registration') && !$user_ID) : ?>
<p><?php _e('You need to','1024px'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>"><?php _e('login','1024px'); ?></a> <?php _e('to post comments!','1024px'); ?></p>
</div>

<?php else : ?>
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
<?php if ($user_ID) : ?>
<p class="loggedin"><?php _e('You are logged in as','1024px'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="<?php _e('Log out','1024px'); ?>"><?php _e('Log out','1024px'); ?></a>.</p>

<?php else : ?>
<p><label for="author"><?php _e('Name','1024px'); ?>:</label><br />
<input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" tabindex="1" /></p>
<p><label for="email"><?php _e('E-mail','1024px'); ?>:</label><br />
<input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" tabindex="2" /></p>
<p><label for="url"><?php _e('URL','1024px'); ?>:</label><br />
<input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" tabindex="3" /></p>

<?php endif; ?>
<p><label for="comment"><?php _e('Message','1024px'); ?>:</label><br />
<textarea name="comment" id="comment" cols="45" rows="4" tabindex="4"></textarea></p>
<p><input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
<input type="submit" name="submit" value="<?php _e('Submit!','1024px'); ?>" class="button" tabindex="5" /></p>
<p><?php do_action('comment_form', $post->ID); ?></p>
</form>
</div>

<?php endif; ?>
<?php endif; ?>