Useful links for theme localization:
http://blog-en.icanlocalize.com/installing-wordpress-for-multiple-language-blogs/how-to-localize-wordpress-themes-and-plugins-with-gettext/
http://www.icanlocalize.com/tools/php_scanner
http://www.poedit.net/

Some strings memo:
<?php _e('','1024px'); ?>
__(,'1024px')
<?php /* LOCALIZED */ ?>